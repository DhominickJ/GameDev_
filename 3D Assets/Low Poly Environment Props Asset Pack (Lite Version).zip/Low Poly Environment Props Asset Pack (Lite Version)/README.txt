Thank you for downloading the Low-Poly Environment Props Asset Pack (Lite Version) by Game Dev Skill Up!

In order to use the models, just extract the zip file in a suitable location.

Please note that this is the lite version of the asset pack, and only includes 5 of the 15 environment
props included in the pack which are: Barrel, Crate, Sack, Vase and Fence. If you would like access to 
all 15 assets, you can buy the full version on the same game page.

If there are any issues or any feedback you have for the asset pack, you can comment on
the asset page or contact me at markryanauman@gmail.com.

- You can use these assets in both commercial and non-commercial projects.
- You can modify these assets if you wish.
- Please do not redistribute or resell these assets, even if they are modified.

If you do end up using this in a game you make, credit would be appreciated but not 
required (I'd like to see your game!).